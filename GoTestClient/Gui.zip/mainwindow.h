#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Network/tcp_client.h"
#include "Gui/ChatUi/emotion_widget.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QStandardItemModel>
#include "Logic/app_cache.h"
#include "sql/sqlite.h"
#include "Gui/ChatUi//screenwidget.h"
#include "./File/filewidget.h"
#include "Gui/ChatUi/send_text_edit.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void setUserName(QString);



    void getMsg(QString msgid);

public slots:
    void on_login_btn_clicked();
signals:

private slots:

    void slotSendMsg(QString msg);
    QString getImageUrl(QString);

    void on_sendmsg_btn_clicked();

    void slotLoginStatus(int status,QString str);

    void slotRecvMsg(MsgBody);

    void slotRecvMsgNotify(MsgBody);

    void slotUpdateMsgStatus(MsgBody);

    void slotGetOfflineNotify(MsgBody);

    void slotRecvOnlineUserList(QString userList);

    void slotOnlineUserUpdate(OnlineListBody body);

    void slotHasImag();

    void on_listWidget_currentTextChanged(const QString &currentText);

    void slotRecvFileCompelte(QString filename,int UserId,QString name);

    void slotSendFileCompelte();

    void slotLoginBody(LoginBody);

    void on_emoji_btn_clicked();

    void slotGetOrg(QJsonDocument json);

    void slotGetUserOrg(QJsonDocument json);

    void slotRecvFileProgress(int totalsize,int seek,int currentsize,int sendstatus,QString fileName);

    void slotSendFileProgress(int totalsize,int seek,int status,QString filename);
protected:
    bool eventFilter(QObject *target, QEvent *event);//事件过滤器

private:
    void init();

    void setBottom();

    void initDB();

    void drawOrg(QJsonDocument);

    void drawUserOrg(QJsonDocument);

    QImage drawLeaveIcon(QString);
private:
    Ui::MainWindow *ui;


    QString         m_currentChoiseUser;
    int             m_currentChoiseUserId;
    QString         m_userName;
    EmotionWidget * m_emojiWidget;
    QStandardItemModel*         m_pModel;
    QMap<int,QList<GlobalUserInfo>> m_userListMap;
    QMap<int,QList<DeptStruct>> m_deptListMap;
    QMap<int,QStandardItem*> m_id2UiPointer;
    QMap<QString,QStandardItem*> m_userName2UiPointer;
    QMap<int,QStandardItem*> m_userId2UiPointer;
    Sqlite          m_sql;
    FileWidget      *m_fileWidget = nullptr;
    QString         m_fileSendName;
    SendTextEdit   * m_ceshiSend;
private slots:
    void clicked(const QModelIndex &index);
    void on_status_comboBox_currentIndexChanged(int index);
    void on_image_btn_clicked();
    void on_screen_btn_clicked();
    void on_screen_noself_btn_clicked();
    void on_file_btn_clicked();
};
#endif // MAINWINDOW_H
