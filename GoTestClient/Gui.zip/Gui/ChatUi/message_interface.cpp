#include "message_interface.h"
#include "ui_message_interface.h"

MessageInterface::MessageInterface(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MessageInterface)
{
    ui->setupUi(this);
}

MessageInterface::~MessageInterface()
{
    delete ui;
}

void MessageInterface::addNewMsg(const MsgBody &msg)
{
    MessageBoxItem *w = new MessageBoxItem();
    w->initMsg(msg);
    QList<MessageBoxItem*> tlist = ui->scrollArea->findChildren<MessageBoxItem*>();
    ui->verticalLayout->insertWidget(tlist.size(),w);
}

void MessageInterface::addNewFileMsg(const QString &filePath, int type)
{
    MessageBoxItem *w = new MessageBoxItem();
    w->initMsg(filePath,type);
    QList<MessageBoxItem*> tlist = ui->scrollArea->findChildren<MessageBoxItem*>();
    ui->verticalLayout->insertWidget(tlist.size(),w);
}

void MessageInterface::updateMsgReadStatus(QString msgId, int status)
{
    QList<MessageBoxItem*> tlist = ui->scrollArea->findChildren<MessageBoxItem*>();

    for(auto it : tlist){
        if(it->getMsgId() == msgId){
            it->updateMsgReadStatus(status);
        }
    }
}

void MessageInterface::clear()
{
    QList<MessageBoxItem*> tlist = ui->scrollArea->findChildren<MessageBoxItem*>();
    foreach(MessageBoxItem* marker, tlist)
    {
        if(marker){
            marker->deleteLater();
            marker = nullptr;
        }
    }
}
