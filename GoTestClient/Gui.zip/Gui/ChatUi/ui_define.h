#ifndef UI_DEFINE_H
#define UI_DEFINE_H
#include <QObject>


#define ImageHeader "%$imgstart"
#define ImageEnd "%$imgend"
#define EmjHeader "%$emjstart"
#define EmjEnd "%$emjend"


enum EmojiName{
    emoji1,
    emoji2,
    emoji3,
    emoji4,
    emoji5,
    emoji6,
    emoji7,
};

const QStringList EmojiPath{
    ":/resource/emoji/1.gif",
    ":/resource/emoji/2.gif",
    ":/resource/emoji/3.gif",
    ":/resource/emoji/4.gif",
    ":/resource/emoji/5.gif",
    ":/resource/emoji/6.gif",
    ":/resource/emoji/7.gif",
};

#endif // UI_DEFINE_H
