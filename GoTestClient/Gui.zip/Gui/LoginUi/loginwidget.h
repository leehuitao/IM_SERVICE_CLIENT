#ifndef LOGINWIDGET_H
#define LOGINWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QTimer>
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>
#include <QGraphicsColorizeEffect>>
#include <QDebug>
#include "Logic/app_cache.h"
#include "mainwindow.h"
namespace Ui {
class LoginWidget;
}

class LoginWidget : public QWidget
{
    Q_OBJECT

public:
    explicit LoginWidget(QWidget *parent = nullptr);
    ~LoginWidget();
    //透明度动画
    void transparenceAnimation();
private slots:
    void on_loginBtn_clicked();

    void on_registerBtn_clicked();

private:
    bool checkUser(QString account,QString password);

    MainWindow w;
    Ui::LoginWidget *ui;
    QTimer *timer;
    QLabel * label;
    QPropertyAnimation *animation;
    QGraphicsOpacityEffect *goe;
    QGraphicsColorizeEffect * gce;
    float m_opacityVal = 1.0f;
};

#endif // LOGINWIDGET_H
