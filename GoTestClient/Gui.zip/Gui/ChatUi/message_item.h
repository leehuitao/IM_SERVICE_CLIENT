#ifndef MESSAGEITEM_H
#define MESSAGEITEM_H

#include <QObject>
#include <QTextEdit>
#include <QTextBlock>
#include <QTextCursor>
#include <QMouseEvent>
#include <QUrl>
#include <QDebug>

#include "Network/packet_define.h"
class MessageItem: public QTextEdit
{
    Q_OBJECT
public:
    MessageItem(QWidget *parent = nullptr);

    void initMsg(const MsgBody &msg);

signals:
    void signImageClicked(const QString & imagePath );
protected:
    void mousePressEvent(QMouseEvent *event) override ;
    void mouseDoubleClickEvent(QMouseEvent *event) override ;

    void parseMsg(const QString & msg);
};

#endif // MESSAGEITEM_H
