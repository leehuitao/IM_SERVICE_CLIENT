#include "loginwidget.h"
#include "ui_loginwidget.h"

#include <QDesktopServices>

LoginWidget::LoginWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginWidget)
{
    ui->setupUi(this);
//    setWindowFlags(Qt::FramelessWindowHint);
    setWindowTitle("超信");
    setWindowIcon(QIcon(":/resource/self.png"));
    this->resize(600,200);
    label = new QLabel(this);
    label->setText("信息有误");
    label->hide();
    //透明度
    goe = new QGraphicsOpacityEffect();
    label->setGraphicsEffect(goe);

    //移动动画
    animation = new QPropertyAnimation(label, "geometry");
    connect(animation,&QPropertyAnimation::finished,this,[=](){
        label->hide();
        timer->stop();
    });
    timer = new QTimer();
    //设置高精度定时器
    //timer->setTimerType(Qt::PreciseTimer);
    connect(timer,&QTimer::timeout,this,&LoginWidget::transparenceAnimation);
}

LoginWidget::~LoginWidget()
{
    delete ui;
}

void LoginWidget::on_loginBtn_clicked()
{
    QString account = ui->accountEdit->text();
    QString password = ui->passwordEdit->text();
    bool ret = checkUser(account,password);
    if(ret)
    {
        AppCache::Instance()->m_userLoginName = account;
        AppCache::Instance()->m_passWord = password;

        w.show();
        w.on_login_btn_clicked();
        this->close();
    }
    else
    {
        m_opacityVal = 1.0f;
        int t = 1500;//动画时间
        //移动动画
        animation->setDuration(t);//设置动画时间
        animation->setEndValue(QRect((this->width()-label->width())/2, 0, 150, 40));//开始位置
        animation->setStartValue(QRect((this->width()-label->width())/2, this->height()/2, 150, 40));//结束位置
        animation->start();//动画开始
        label->show();
        timer->start(t/10);
    }
}

void LoginWidget::on_registerBtn_clicked()
{
    const QUrl regUrl(QLatin1String("http://www.baidu.com"));
    QDesktopServices::openUrl(regUrl);
}

bool LoginWidget::checkUser(QString account, QString password)
{
    return 1;
}

void LoginWidget::transparenceAnimation()
{
   m_opacityVal -= 0.1;
   goe->setOpacity(m_opacityVal);
}
