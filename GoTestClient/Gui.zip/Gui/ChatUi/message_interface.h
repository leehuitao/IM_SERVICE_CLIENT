#ifndef MESSAGE_INTERFACE_H
#define MESSAGE_INTERFACE_H

#include <QWidget>
#include "message_box_item.h"
namespace Ui {
class MessageInterface;
}

class MessageInterface : public QWidget
{
    Q_OBJECT

public:
    explicit MessageInterface(QWidget *parent = nullptr);
    ~MessageInterface();

    void addNewMsg(const MsgBody &msg);
    /**
        增加文件发送消息
        type = 0  发送文件成功消息
        type = 1  接收文件成功消息
    */
    void addNewFileMsg(const QString &filePath,int type = 0);
    //更新消息状态
    void updateMsgReadStatus(QString msgId, int status);

    void clear();
private:
    Ui::MessageInterface *ui;
    int currentDisplayUserId = -1;
    //用于刷新界面新消息
    int currentDisplayLastTime = -1;
    //当前显示的消息数量
    int currentDisplayMsgNum = 0;
};

#endif // MESSAGE_INTERFACE_H
