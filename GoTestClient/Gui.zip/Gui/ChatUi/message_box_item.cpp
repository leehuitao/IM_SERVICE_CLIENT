#include "message_box_item.h"
#include "ui_message_box_item.h"

#include <QDesktopServices>
#include <QProcess>
#include "Logic/app_cache.h"

MessageBoxItem::MessageBoxItem(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MessageBoxItem)
{
    ui->setupUi(this);
}

MessageBoxItem::~MessageBoxItem()
{
    delete ui;
}

void MessageBoxItem::updateMsgReadStatus(int status)
{
    if(status == 1){
        ui->self_msg_state_lab->setText("未读");
    }else if(status == 2){
        ui->self_msg_state_lab->setText("已读");
    }else{
        ui->self_msg_state_lab->setText("错误");
    }
}

void MessageBoxItem::initMsg(const QString &filePath, int type)
{
    m_filePath = filePath;
    if(type == 0){
        setDisPlayWid(3);
        ui->send_file_name_lab->setText(filePath.split("/").last());
    }else if(type == 1){
        setDisPlayWid(4);
        ui->recv_file_name_lab->setText(filePath.split("/").last());
    }
}

void MessageBoxItem::initMsg(const MsgBody &msg)
{
    m_msgId = msg.MsgId;
    //绘制用户头像
    setUserAvatar(msg.SendUserId);
    //是我发送的消息
    if(msg.SendUserId == AppCache::Instance()->m_userId){
        // 设置对齐方式
        setDisPlayWid(1);
        ui->self_textEdit->setAlignment(Qt::AlignRight); // 右对齐
        ui->self_textEdit->initMsg(msg);
        if(msg.MsgStatus == 0){//发送中
            ui->self_msg_state_lab->setText("发送中");
        }else if(msg.MsgStatus == 1){//未读
            ui->self_msg_state_lab->setText("未读");
        }else if(msg.MsgStatus == 2){//已读
            ui->self_msg_state_lab->setText("已读");
        }else{//错误
            return;
        }
    }else if(msg.DstUserId == AppCache::Instance()->m_userId){//是我接收的消息
        // 设置对齐方式
        setDisPlayWid(2);
        ui->other_textEdit->setAlignment(Qt::AlignLeft); // 左对齐
        ui->other_textEdit->initMsg(msg);
    }else{//用户ID错误
        return;
    }
}

void MessageBoxItem::on_open_file_btn_clicked()
{
    // 使用QDesktopServices打开文件
    QUrl fileUrl = QUrl::fromLocalFile(m_filePath);
    if (QDesktopServices::openUrl(fileUrl)) {
        // 文件成功打开
    } else {
        // 处理打开文件失败
    }

}

void MessageBoxItem::on_open_dir_btn_clicked()
{
    QProcess process;
    QString paht = m_filePath.replace("/", "\\"); // 只能识别 "\"
    QString cmd = QString("explorer.exe /select,\"%1\"").arg(paht);
    qDebug() << cmd;
    process.startDetached(cmd);

}

void MessageBoxItem::setDisPlayWid(int index)
{
    if(index == 1){//我发送的
        ui->self_wid->show();
        ui->other_wid->hide();
        ui->recv_file_wid->hide();
        ui->send_file_wid->hide();
    }else if(index == 2){//我接收的

        ui->self_wid->hide();
        ui->other_wid->show();
        ui->recv_file_wid->hide();
        ui->send_file_wid->hide();
    }else if(index == 3){//发送文件成功
        ui->self_wid->hide();
        ui->other_wid->hide();
        ui->recv_file_wid->hide();
        ui->send_file_wid->show();
    }else if(index == 4){//接收文件成功
        ui->self_wid->hide();
        ui->other_wid->hide();
        ui->recv_file_wid->show();
        ui->send_file_wid->hide();
    }
}

void MessageBoxItem::setUserAvatar(int userId)
{
    if(userId == AppCache::Instance()->m_userId){//我发送的
        ui->self_icon_lab->setPixmap(QPixmap(":/resource/self.png"));
    }else{//我接收的
        ui->other_icon_lab->setPixmap(QPixmap(":/resource/other.png"));
    }
}
