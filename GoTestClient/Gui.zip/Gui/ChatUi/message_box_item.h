#ifndef MESSAGE_BOX_ITEM_H
#define MESSAGE_BOX_ITEM_H

#include <QWidget>
#include "message_item.h"
namespace Ui {
class MessageBoxItem;
}

class MessageBoxItem : public QWidget
{
    Q_OBJECT

public:
    explicit MessageBoxItem(QWidget *parent = nullptr);
    ~MessageBoxItem();

    void initMsg(const MsgBody &msg);
    /**
        增加文件发送消息
        type = 0  发送文件成功消息
        type = 1  接收文件成功消息
    */
    void initMsg(const QString &filePath,int type = 0);

    void updateMsgReadStatus(int status);

    QString getMsgId() const {
        return m_msgId;
    }
private slots:
    void on_open_file_btn_clicked();

    void on_open_dir_btn_clicked();

    void setDisPlayWid(int index);
    //设置用户头像
    void setUserAvatar(int userId);
private:
    Ui::MessageBoxItem *ui;
    QString m_msgId = "";
    QString m_filePath = "";
};

#endif // MESSAGE_BOX_ITEM_H
