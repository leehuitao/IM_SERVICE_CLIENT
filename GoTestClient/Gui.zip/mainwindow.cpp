﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QThread>
#include <QDateTime>
#include <QFileDialog>
#include <QNetworkInterface>
#include <QScrollBar>
#include <QThread>
#include <QJsonDocument>
#include <QStandardItemModel>
#include <QTextEdit>
#include <QKeyEvent>
#include <QPainter>
#include <QTextDocumentFragment>
#include <QMimeData>
#include <QUuid>
#include "Logic/global_center.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    init();
    setWindowTitle("超信");
    setWindowIcon(QIcon(":/resource/self.png"));

    ui->msg_send_edit->installEventFilter(this);//设置完后自动调用其eventFilter函数
    initDB();
    connect(ui->msg_send_edit , &SendTextEdit::signSendMsg,[=](QString msg){
        slotSendMsg(msg);
    });
    if(m_fileWidget == nullptr)
    {
        m_fileWidget = new FileWidget();
        connect(m_fileWidget,&FileWidget::signFileCmd,GlobalCenter::getInstance(),&GlobalCenter::slotFileCmd);
    }
    m_ceshiSend = new SendTextEdit;
}

MainWindow::~MainWindow()
{
    delete ui;
}
bool MainWindow::eventFilter(QObject *target, QEvent *event)
{
    if(target == ui->msg_send_edit)		//可替换
    {
        if(event->type() == QEvent::KeyPress )//回车键
        {
            QKeyEvent *k = static_cast<QKeyEvent *>(event);

            if(k->key() == Qt::Key_Return || k->key() == Qt::Key_Enter)
            {
                on_sendmsg_btn_clicked();
                return true;
            }
        }
    }
    return QWidget::eventFilter(target,event);
}

void MainWindow::setUserName(QString username)
{
    AppCache::Instance()->m_userName = username;
}

void MainWindow::on_login_btn_clicked()
{
    QString ip = ui->ip->text();
    int port   = ui->port->text().toInt();

    GlobalCenter::getInstance()->initTcp(ip,port);
}

void MainWindow::getMsg(QString msgid)
{
    MsgBody body;
    body.MsgId = msgid;
    body.UserId = AppCache::Instance()->m_userId;
    GlobalCenter::getInstance()->signGetMsg(body);
//    signGetMsg(body);
}

void MainWindow::slotSendMsg(QString msg)
{

}

QString MainWindow::getImageUrl(QString url)
{

}

void MainWindow::on_sendmsg_btn_clicked()
{
    auto msg = ui->msg_send_edit->getMsg();
    auto body = GlobalCenter::getInstance()->sendMsg(msg);
    ui->history_wid->addNewMsg(body);
    ui->msg_send_edit->clear();
}

void MainWindow::slotLoginStatus(int status, QString str)
{
    if(status){
        ui->login_status_lab->setStyleSheet("background-color: rgb(0, 255, 0);");
        ui->login_btn->setText("quit");
    }else{
        ui->login_status_lab->setStyleSheet("background-color: rgb(255, 0, 0);");
        ui->login_btn->setText("login");
    }
    ui->login_status_str_lab->setText(str);
}

void MainWindow::slotRecvMsg(MsgBody body)
{
    if(body.SendUserId == AppCache::Instance()->m_userId){//表示发送消息成功了，插入本地数据库，更新消息状态为未读
        ui->history_wid->updateMsgReadStatus(body.MsgId,body.MsgStatus);
        m_sql.insertHistoryMsg(body);
    }else if(body.DstUserId == AppCache::Instance()->m_userId){//接收到消息了 
         m_sql.insertHistoryMsg(body);
         if(m_currentChoiseUserId == body.SendUserId){
             ui->history_wid->addNewMsg(body);
             body.MsgStatus = 2;
             body.UserId = AppCache::Instance()->m_userId;
             slotUpdateMsgStatus(body);
         }
    }
     qDebug()<<__FUNCTION__<<body.Msg;
}

void MainWindow::slotRecvMsgNotify(MsgBody body)
{
    auto list = body.MsgId.split("|");
    for(auto it : list){
        if(it.isEmpty())
            getMsg(it);
    }

}

void MainWindow::slotUpdateMsgStatus(MsgBody body)
{
    ui->history_wid->updateMsgReadStatus(body.MsgId,body.MsgStatus);
    qDebug()<<__FUNCTION__<<body.Msg;
    m_sql.updateMsgStatus(body.MsgId,body.MsgStatus);
    GlobalCenter::getInstance()->signUpdateMsgStatus(body);

}

void MainWindow::slotGetOfflineNotify(MsgBody body)
{
    auto list = body.MsgId.split("|");
    for(auto it : list){
        if(!it.isEmpty())
            getMsg(it);
    }
}

void MainWindow::slotRecvOnlineUserList(QString userList)
{
    qDebug()<<__FUNCTION__<<userList;
    //    QStringList list = userList.split(",");
    // 解析 JSON 字符串
    QMap<int,int> userStatus;
    QJsonDocument jsonDocument = QJsonDocument::fromJson(userList.toUtf8());
    if (!jsonDocument.isNull() && jsonDocument.isObject()) {
        QJsonObject jsonObject = jsonDocument.object();
        QStringList keys = jsonObject.keys();

        // 遍历解析后的 JSON 对象
        for (const QString &key : keys) {
            QJsonValue value = jsonObject.value(key);
            userStatus[key.toInt()] = value.toInt();
            //qDebug() << "Key:" << key << "Value:" << value.toInt();
        }
    } else {
        qDebug() << "Failed to parse JSON.";
    }
    auto keys = userStatus.keys();
    for(auto it : keys){
        if(it >= 88880000){
            auto status = userStatus[it];
            if(it == AppCache::Instance()->m_userId){
                if(status == UserLoginStatus){
                    m_userId2UiPointer[it]->setIcon(QIcon(":/resource/self.png"));
                }else if(status == UserLeaveStatus){
                    QIcon combinedIcon;
                    combinedIcon.addPixmap(QPixmap::fromImage( drawLeaveIcon(":/resource/self.png"))); // 调整头像大小
                    m_userId2UiPointer[it]->setIcon(combinedIcon);
                }
            }
            else{
                if(status == UserLoginStatus){
                    m_userId2UiPointer[it]->setIcon(QIcon(":/resource/other.png"));
                }else if(status == UserLeaveStatus){
                    QIcon combinedIcon;
                    combinedIcon.addPixmap(QPixmap::fromImage( drawLeaveIcon(":/resource/other.png"))); // 调整头像大小
                    m_userId2UiPointer[it]->setIcon(combinedIcon);
                }
            }

        }
    }

    //更新所有在线人员后   获取未读消息
    SystemBody body;
    body.UserId=AppCache::Instance()->m_userId;

    GlobalCenter::getInstance()->signGetOfflineMsg(body);
}

void MainWindow::slotOnlineUserUpdate(OnlineListBody body)
{
    if(body.Status == UserLoginStatus){
        if(body.UserId == AppCache::Instance()->m_userId)
            m_userId2UiPointer[body.UserId]->setIcon(QIcon(":/resource/self.png"));
        else{
            if(m_userId2UiPointer[body.UserId])
                m_userId2UiPointer[body.UserId]->setIcon(QIcon(":/resource/other.png"));
        }
    }else if(body.Status == UserLeaveStatus){
        // 创建用户头像和状态图标组合
        QIcon combinedIcon;
        if(body.UserId == AppCache::Instance()->m_userId){
            combinedIcon.addPixmap(QPixmap::fromImage( drawLeaveIcon(":/resource/self.png"))); // 调整头像大小
            m_userId2UiPointer[body.UserId]->setIcon(combinedIcon);
        }
        else{
            combinedIcon.addPixmap(QPixmap::fromImage( drawLeaveIcon(":/resource/other.png")));
            m_userId2UiPointer[body.UserId]->setIcon(combinedIcon);
        }
    }
    else if(body.Status == UserLogoffStatus){
        if(m_userId2UiPointer[body.UserId])
            m_userId2UiPointer[body.UserId]->setIcon(QIcon(":/resource/offline.png"));
    }
}

void MainWindow::slotHasImag()
{
    QClipboard *clipboard = QApplication::clipboard();
    const QMimeData *mimeData = clipboard->mimeData();
    if (mimeData->hasImage())
    {
        //将图片数据转为QImage
        QImage img = qvariant_cast<QImage>(mimeData->imageData());
        QString fileName = QString("%1/screen_%2.png").arg(qApp->applicationDirPath()).arg(GlobalCenter::getInstance()->getCurrentTimeSeconds());
        img.save(fileName);
        QTextDocumentFragment fragment;
        fragment = QTextDocumentFragment::fromHtml(QString("<img src='%1'>").arg(fileName));
        ui->msg_send_edit->textCursor().insertFragment(fragment);
        ui->msg_send_edit->setVisible(true);
    }
}


void MainWindow::init(){

    m_emojiWidget = new EmotionWidget;
    m_emojiWidget->initEmotion();
    connect(m_emojiWidget ,&EmotionWidget::emojiWidgetClose, [=]{
        ui->msg_send_edit->setFocus();
    });

    connect(m_emojiWidget,&EmotionWidget::emojiClicked,[=](int number){
        ui->msg_send_edit->insertEmoji(number);
        //        QTextCursor cursor = ui->msg_send_edit->textCursor();
        //        QTextDocument *document = ui->msg_send_edit->document();
        //        //cursor.movePosition(QTextCursor::End);
        //        cursor.insertImage(QString(":/resource/emoji/%1.gif").arg(number+1));
    });
    m_pModel = new QStandardItemModel(ui->treeView);
    ui->treeView->header()->hide();
    ui->treeView->setModel(m_pModel);
    ui->treeView->setEditTriggers(QHeaderView::NoEditTriggers);
    ui->treeView->setIconSize(QSize(40,40));
    ui->treeView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->treeView->setContextMenuPolicy(Qt::CustomContextMenu);

    connect(ui->treeView, SIGNAL(clicked(QModelIndex)),
            this, SLOT(clicked(QModelIndex)));
    connect(ScreenWidget::Instance(),&ScreenWidget::signHasImag,this,&MainWindow::slotHasImag);

    connect(GlobalCenter::getInstance() ,&GlobalCenter::signLoginStatus,       this,&MainWindow::slotLoginStatus               ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signLoginBody,         this,&MainWindow::slotLoginBody                 ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signRecvMsg,           this,&MainWindow::slotRecvMsg                   ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signRecvFileProgress,  this,&MainWindow::slotRecvFileProgress          ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signOnlineUserList,    this,&MainWindow::slotRecvOnlineUserList        ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signOnlineUserUpdate,  this,&MainWindow::slotOnlineUserUpdate          ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signSendFileProgress,  this,&MainWindow::slotSendFileProgress          ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signRecvFileCompelte,  this,&MainWindow::slotRecvFileCompelte          ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signSendFileCompelte,  this,&MainWindow::slotSendFileCompelte          ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signGetOrgRes,         this,&MainWindow::slotGetOrg                    ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signGetUserOrg,        this,&MainWindow::slotGetUserOrg                ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signRecvMsgNotify,     this,&MainWindow::slotRecvMsgNotify          ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signMsgHadBeenRead,    this,&MainWindow::slotUpdateMsgStatus          ,Qt::QueuedConnection);
    connect(GlobalCenter::getInstance() ,&GlobalCenter::signGetOfflineNotify,  this,&MainWindow::slotGetOfflineNotify          ,Qt::QueuedConnection);

}

void MainWindow::setBottom()
{
    //    QScrollBar *pScrollBar = ui->scrollArea->verticalScrollBar();
    //    if (pScrollBar != nullptr)
    //    {
    //        int nMax = pScrollBar->maximum();
    //        pScrollBar->setValue(nMax);
    //    }
}

void MainWindow::initDB()
{
    m_sql.initDB();
}

void MainWindow::drawOrg(QJsonDocument json)
{
    m_pModel->clear();
    m_deptListMap.clear();
    m_id2UiPointer.clear();
    m_userId2UiPointer.clear();
    m_userListMap.clear();
    auto jsonobj = json.object();
    auto keys    = jsonobj.keys();
    for(auto it : keys){
        auto jval = jsonobj.value(it);

        QByteArray details = QByteArray::fromBase64(jval.toString().toLocal8Bit().data());

        QJsonParseError jsonError;
        QJsonDocument jsonDoc(QJsonDocument::fromJson(details, &jsonError));
        if(jsonError.error != QJsonParseError::NoError)
        {
            qDebug() << "json error!" << jsonError.errorString();
            return;
        }
        auto values = jsonDoc.object();
        QString deptName = QString::fromLocal8Bit( values.value("DeptName").toString().toLocal8Bit());
        int DeptID = values.value("DeptID").toInt();
        int ParentDeptID = values.value("ParentDeptID").toInt();
        int Level = values.value("Level").toInt();
        DeptStruct d;
        d.DeptName = deptName;
        d.DeptId = DeptID;
        d.ParentDeptId = ParentDeptID;
        d.Level = Level;
        m_deptListMap[Level].append(d);
    }
    for(auto it : m_deptListMap){
        for(auto item : it){
            auto group = new QStandardItem(item.DeptName);
            m_id2UiPointer[item.DeptId] = group;
            if(item.ParentDeptId != 0){
                m_id2UiPointer[item.ParentDeptId]->appendRow(group);
            }else{
                m_pModel->appendRow(group);
            }
        }
    }
    ui->treeView->expandAll();
}

void MainWindow::drawUserOrg(QJsonDocument json)
{
    auto jsonobj = json.object();
    auto keys    = jsonobj.keys();
    for(auto it : keys){
        auto jval = jsonobj.value(it);

        QByteArray details = QByteArray::fromBase64(jval.toString().toLocal8Bit().data());

        QJsonParseError jsonError;
        QJsonDocument jsonDoc(QJsonDocument::fromJson(details, &jsonError));
        if(jsonError.error != QJsonParseError::NoError)
        {
            qDebug() << "json error!" << jsonError.errorString();
            return;
        }
        auto values = jsonDoc.object();
        QString UserName = values.value("UserName").toString();
        int     UserId = values.value("UserId").toInt();
        int     DeptID = values.value("DeptId").toInt();
        GlobalUserInfo u;
        u.UserName = UserName;
        u.UserId = UserId;
        u.DeptId = DeptID;
        m_userListMap[DeptID].append(u);
    }
    for(auto it : m_userListMap){
        for(auto user : it){
            if (user.DeptId == 0)
                continue;
            auto item = new QStandardItem();
            item->setIcon(QIcon(":/resource/offline.png"));
            item->setText(user.UserName);
            item->setSizeHint(QSize(200,50));
            item->setWhatsThis(user.UserName);
            item->setToolTip(QString::number(user.UserId));
            m_id2UiPointer[user.DeptId]->appendRow(item);
            m_userId2UiPointer[user.UserId] = item;
        }
    }
    ui->treeView->expandAll();
}

QImage MainWindow::drawLeaveIcon(QString user)
{
    // 加载用户头像和离开的图片
    QImage userIcon(user);
    QImage leaveIcon(":/resource/leave.png");

    // 创建一个新的 QImage 来容纳合并后的图片
    QImage mergedImage(userIcon.size(), QImage::Format_ARGB32);
    mergedImage.fill(Qt::transparent);

    // 创建一个 QPainter 对象，并将其与合并后的图像关联
    QPainter painter(&mergedImage);

    // 将用户头像绘制在合并后的图像上
    painter.drawImage(0, 0, userIcon);

    // 计算离开图片的绘制位置
    int leaveX = mergedImage.width() - leaveIcon.width();
    int leaveY = mergedImage.height() - leaveIcon.height();

    // 将离开的图片绘制在右下角
    painter.drawImage(leaveX, leaveY, leaveIcon);

    painter.end();
    return mergedImage;
}

void MainWindow::clicked(const QModelIndex &index)
{
    m_currentChoiseUser = index.data(Qt::WhatsThisRole).toString();
    m_currentChoiseUserId = index.data(Qt::ToolTipRole).toInt();
    GlobalCenter::getInstance()->setCurrentUser(m_currentChoiseUserId,m_currentChoiseUser);
    if(m_currentChoiseUserId == 0)
        return;
    AppCache::Instance()->m_msgSize = 0;

    auto list = m_sql.selectHistoryMsg(m_currentChoiseUserId,AppCache::Instance()->m_userId);
    ui->history_wid->clear();
    for(auto it : list){
        MsgBody body(it);
        ui->history_wid->addNewMsg(body);
        if(body.MsgStatus == 1 && body.DstUserId == AppCache::Instance()->m_userId){//如果时未读消息
            body.UserId = AppCache::Instance()->m_userId;
            body.MsgStatus = 2;
            slotUpdateMsgStatus(body);
        }
    }
    qDebug()<<index.data()<<index.data(Qt::WhatsThisRole);
}

void MainWindow::on_listWidget_currentTextChanged(const QString &currentText)
{
    qDebug()<<__FUNCTION__<<currentText<<" clicked ";
    m_currentChoiseUser = currentText;
}

void MainWindow::slotRecvFileCompelte(QString filename, int UserId , QString senderName)
{
    MsgBody body;
    body.UserId = UserId;
    body.Msg = "recv file success:"+filename;
    m_fileWidget->hide();
}

void MainWindow::slotSendFileCompelte()
{
    m_fileWidget->hide();
}

void MainWindow::slotLoginBody(LoginBody body)
{
    ui->username_lab->setText(body.UserName);
    AppCache::Instance()->m_userName = body.UserName;
    AppCache::Instance()->m_userLoginName = body.UserLoginName;
}

void MainWindow::on_emoji_btn_clicked()
{
    if(!m_emojiWidget->isVisible()){
        m_emojiWidget->move(ui->emoji_btn->x()+this->x()-(m_emojiWidget->width()*0.5),ui->emoji_btn->y()+this->y()-m_emojiWidget->height()+23);

        m_emojiWidget->show();
    }else{
        m_emojiWidget->hide();
    }

}

void MainWindow::slotGetOrg(QJsonDocument json)
{
    //获取组织架构后更新人员组织
    SystemBody body;
    body.UserId = AppCache::Instance()->m_userId;
    body.SystemCMD      = "0";
    drawOrg(json);
    GlobalCenter::getInstance()->signGetOrg(body,GetUserOrg,0);

}

void MainWindow::slotGetUserOrg(QJsonDocument json)
{
    //    qDebug()<<json;
    //获取人员组织后更新在线人员
    SystemBody body;
    body.UserId  = AppCache::Instance()->m_userId;
    body.SystemCMD      = "0";
    drawUserOrg(json);
    GlobalCenter::getInstance()->signGetOrg(body,GetOnlineUser,0);
}

void MainWindow::on_status_comboBox_currentIndexChanged(int index)
{
    LoginBody body;
    body.UserId = AppCache::Instance()->m_userId;
    body.UserLoginName   = AppCache::Instance()->m_userName;
    body.UserName   = AppCache::Instance()->m_userName;
    body.LoginStatus = index +1;
    GlobalCenter::getInstance()->signUpdateStatus(body,UpdateUserStatus,0);

}

void MainWindow::on_image_btn_clicked()
{

}

void MainWindow::on_screen_btn_clicked()
{
    if(ScreenWidget::Instance()->btn != nullptr)
    {
        ScreenWidget::Instance()->btn->hide();
        ScreenWidget::Instance()->btn = nullptr;
    }
    ScreenWidget::Instance()->showFullScreen();
}

void MainWindow::on_screen_noself_btn_clicked()
{
    this->showMinimized();
    _sleep(500);
    if(ScreenWidget::Instance()->btn != nullptr)
    {
        ScreenWidget::Instance()->btn->hide();
        ScreenWidget::Instance()->btn = nullptr;
    }
    ScreenWidget::Instance()->showFullScreen();
    this->showNormal();
}

void MainWindow::on_file_btn_clicked()
{
    QFileDialog *fileDialog = new QFileDialog(this);
    fileDialog->setWindowTitle(QStringLiteral("选中文件"));
    fileDialog->setDirectory(".");
    fileDialog->setNameFilter(tr("File(*.*)"));
    fileDialog->setFileMode(QFileDialog::ExistingFiles);
    fileDialog->setViewMode(QFileDialog::Detail);
    QStringList fileNames;
    if (fileDialog->exec()) {
        fileNames = fileDialog->selectedFiles();
    }
    if(fileNames.size()>0)
    {
        m_fileWidget->show();
        m_fileWidget->addFileList(fileNames);
        ui->horizontalLayout_5->addWidget(m_fileWidget);
        ui->horizontalLayout_5->setStretchFactor(ui->treeView,1);
        ui->horizontalLayout_5->setStretchFactor(ui->verticalLayout_2,3);
        ui->horizontalLayout_5->setStretchFactor(m_fileWidget,1);
    }
}

void MainWindow::slotRecvFileProgress(int totalsize,int seek,int current,int sendstatus,QString fileName)
{
    //目前有点问题，因为seek第一次的值不是8192
    if(seek != 0 || seek == 8192)
    {
        m_fileWidget->setProgress(totalsize,seek + current,sendstatus,fileName);
        return;
    }
    //进度值为0，说明是新的接收文件，在界面中创建出来
    m_fileWidget->show();
    m_fileWidget->addFileList(QStringList(fileName),1);
    ui->horizontalLayout_5->addWidget(m_fileWidget);
    ui->horizontalLayout_5->setStretchFactor(ui->treeView,1);
    ui->horizontalLayout_5->setStretchFactor(ui->verticalLayout_2,3);
    ui->horizontalLayout_5->setStretchFactor(m_fileWidget,1);

}

void MainWindow::slotSendFileProgress(int totalsize,int seek,int status,QString filename)
{
    m_fileWidget->setProgress(totalsize,seek,status,filename);
}
